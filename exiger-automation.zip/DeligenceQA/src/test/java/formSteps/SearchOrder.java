package formSteps;

import forms.BaseFormClass;
import helpers.Dropdown;
import helpers.Wait;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import step_definitions.BaseClass;
import forms.SearchOrderForm;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class SearchOrder extends BaseClass {
    Wait wait = new Wait();
    Dropdown dropdown = new Dropdown();
    SearchOrderForm search = new SearchOrderForm();

    public void fillordername(String name){
        search.orderName.sendKeys(name);
    }

    public void selectordertype(String ordertypename){
        dropdown.selectValueFromUnorderedListWithCheckbox(driver,search.ordertypediv,search.ordertypebutton, ordertypename);
    }

    public void fillorderstatus(String orderstatusname){
        dropdown.selectValueFromInput(search.orderstatusdiv,search.orderstatusbutton, orderstatusname);

    }

    public void submitcal_1(){
        search.calbtn1.click();
        Calendar cal= Calendar.getInstance();
        int cal_for_month = cal.get(Calendar.DATE);
        cal_for_month = cal_for_month - 1;
        driver.findElement(By.xpath("//*[@id='startSubmitDateContainer']/div/ul/li[1]/div/div[1]/table/tbody/*/td[text()="+cal_for_month+"]")).click();
    }

    public void submitcal_2(){
        search.calbtn2.click();
        Calendar cal= Calendar.getInstance();
        int cal_for_month = cal.get(Calendar.DATE);
        cal_for_month = cal_for_month + 1;
        driver.findElement(By.xpath("//*[@id='endSubmitDateContainer']/div/ul/li[1]/div/div[1]/table/tbody/*/td[text()="+cal_for_month+"]")).click();
    }

    public void submitcal_3(){
        search.calbtn3.click();
        Calendar cal= Calendar.getInstance();
        int cal_for_month = cal.get(Calendar.DATE);
        cal_for_month = cal_for_month - 1;
        driver.findElement(By.xpath("//*[@id='startCompletedDateContainer']/div/ul/li[1]/div/div[1]/table/tbody/*/td[text()="+cal_for_month+"]")).click();
    }

    public void submitcal_4(){
        search.calbtn4.click();
        Calendar cal= Calendar.getInstance();
        int cal_for_month = cal.get(Calendar.DATE);
        cal_for_month = cal_for_month + 1;
        driver.findElement(By.xpath("//*[@id='endCompletedDateContainer']/div/ul/li[1]/div/div[1]/table/tbody/*/td[text()="+cal_for_month+"]")).click();
    }

    public  void ordernumber(String orderno){
        search.ordernumber.sendKeys(orderno);
    }

    public  void searchbuttonclick() {
        search.searchbutton.click();
    }


    public  void resetbuttonclick() {
        search.resetbutton.click();
    }

    public  void viewresults() {
        wait.waitUntilPresent(search.results);
    }

}
