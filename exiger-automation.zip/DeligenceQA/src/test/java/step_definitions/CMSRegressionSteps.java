package step_definitions;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import forms.SearchOrderForm;
import helpers.Dropdown;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import pageobjects.CasePage;
import pageobjects.LoginPage;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import helpers.*;
import pageobjects.OMSDashboardPage;

import java.util.ArrayList;
import java.util.Set;

public class CMSRegressionSteps extends BaseClass {
    Wait wait = new Wait();
    LoginPage loginPage = new LoginPage();
    CasePage casePage = new CasePage();
    Dropdown dropdown = new Dropdown();
    SearchOrderForm search = new SearchOrderForm();
    PopupWindow popupWindow = new PopupWindow();
    ScrollintoView scrollintoView = new ScrollintoView();
    OMSDashboardPage omsDashboardPage = new OMSDashboardPage();

    @And("^I login to CMS site$")
    public void iLoginToCMSSite() throws Throwable {
        loginPage.navigateToDiligenceLoginPage();
        loginPage.userName.sendKeys("tdattacm@exiger.com");
        loginPage.password.sendKeys("Admin123!");
        loginPage.loginButton.click();
    }

    @And("^I click on Cases$")
    public void iClickOnCases() throws Throwable {
        driver.findElement(By.linkText("Cases")).click();
    }


    @And("^I click on Search button$")
    public void iClickOnSearchButton() throws Throwable {
        casePage.searchButton.click();

    }

    @And("^I select \"([^\"]*)\" in Status Dropdown$")
    public void iSelectInStatusDropdown(String arg0) throws Throwable {
        //driver.findElement((By) casePage.statusDropdown).click();
        dropdown.selectValueFromUnorderedListWithCheckbox(driver, search.ordertypediv, search.ordertypebutton, arg0);

    }

    @And("^I click on Order Submitted on date (\\d+)/(\\d+)/(\\d+)$")
    public void iClickOnOrderSubmittedOnDate(int arg0, int arg1, int arg2) throws Throwable {
        System.out.println(driver.findElement(By.id("load_jqGrid")).getSize());
        wait.waitUntilGridSpinnersNotPresent();
        wait.waitAndClick(casePage.firstrow);
    }

    @And("^I navigate to Case Summary Page$")
    public void iNavigateToCaseSummaryPage() throws Throwable {
        popupWindow.moveToNewTab();

    }

    @And("^I click on Edit Core Details$")
    public void iClickOnEditCoreDetails() throws Throwable {
        scrollintoView.scrollToView(casePage.coredetails);
        casePage.coredetailslink.click();

    }

    @And("^I enter date in Interim Report Due Date$")
    public void iEnterDateInInterimReportDueDate() throws Throwable {
        casePage.duedate.sendKeys("t");
        casePage.interimreportduedate.sendKeys("t");
    }

    @And("^I click on Complete checkbox$")
    public void iClickOnCompleteCheckbox() throws Throwable {
        casePage.interimreportcheckbox.click();
    }

    @Then("^I click on Save Core Details$")
    public void iClickOnSaveCoreDetails() throws Throwable {
        casePage.savecoredetails.click();
        Thread.sleep(10000);

    }

    @And("^Remember Me Checkbox is Present$")
    public void rememberMeCheckboxIsPresent() throws Throwable {
        loginPage.rememberMeButton.isDisplayed();
    }

    @Then("^I check the Remember Me box$")
    public void iCheckTheRememberMeBox() throws Throwable {
        loginPage.rememberMeButton.click();
        Assert.assertTrue(loginPage.rememberMeButton.isSelected());
    }

    @And("^I navigate to login page$")
    public void iNavigateToLoginPage() throws Throwable {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement dropdown = driver.findElement(By.cssSelector(".dropdown-menu"));
        js.executeScript("arguments[0].setAttribute('style', 'display:block;')", dropdown);

        omsDashboardPage.logOff.click();

        loginPage.navigateToDiligenceLoginPage();
    }

    @And("^I click on Forgot Password$")
    public void iClickOnForgotPassword() throws Throwable {
        omsDashboardPage.forgotpassword.click();
    }

    @And("^I enter username$")
    public void iEnterUsername() throws Throwable {
        loginPage.userName.sendKeys("tdattacm@exiger.com");
        loginPage.loginButton.click();
    }

    @Then("^I get password reset email sent message$")
    public void iGetPasswordResetEmailSentMessage() throws Throwable {
        Assert.assertTrue(driver.findElement(By.cssSelector(".temp-alert-top.alert.alert-dismissible.alert-success")).isDisplayed());
    }


    @And("^I change the language to English$")
    public void iChangeTheLanguageToEnglish() throws Throwable {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement dropdown = driver.findElement(By.cssSelector(".dropdown-menu"));
        js.executeScript("arguments[0].setAttribute('style', 'display:block;')", dropdown);

        omsDashboardPage.language.click();
    }

    @And("^I click on support link in CMS$")
    public void iClickOnSupportLinkInCMS() throws Throwable {
        omsDashboardPage.support.click();
    }

    @And("^I navigate to support page in CMS$")
    public void iNavigateToSupportPageInCMS() throws Throwable {
        wait.waitAndClick(omsDashboardPage.supportverify);
    }
}