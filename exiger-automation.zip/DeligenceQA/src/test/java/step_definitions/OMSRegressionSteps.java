package step_definitions;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.github.javafaker.Faker;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import formSteps.CreateOrder;

import formSteps.SearchOrder;
import helpers.*;

import helpers.Wait;
import helpers.WebElementExtensions;
import org.hamcrest.CoreMatchers;
import org.junit.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import pageobjects.*;
import util.Credentials;

import java.text.SimpleDateFormat;
import java.util.*;

import static junit.framework.TestCase.assertTrue;


public class OMSRegressionSteps extends BaseClass {
    LoginPage loginPage = new LoginPage();
    Wait wait = new Wait();
    WebElementExtensions webElementExtensions = new WebElementExtensions();
    OMSDashboardPage omsDashboardPage = new OMSDashboardPage();
    CreateOrder createOrder = new CreateOrder();
    OrderPage orderPage = new OrderPage();
    HomePage  homePage = new HomePage(driver);
    SearchOrder searchorderpage = new SearchOrder();
    OrderSearchPage orderSearchPage = new OrderSearchPage();
    CasePage casePage = new CasePage();
    String companyName = null;
    SubjectCompanyFormPage subjectCompanyFormPage = new SubjectCompanyFormPage(driver);
    private ReviewAndConfirmOrderPage rco = new ReviewAndConfirmOrderPage(driver);

    PageHelpers pageHelpers = new PageHelpers();
    Credentials credentials = new Credentials();
    SelectElements selectElements = new SelectElements();
    Dropdown dropdown = new Dropdown();

    Faker faker = new Faker();
    String orderName = faker.superhero().name() + " order";
    String[] orders = null;


    @When("^I navigate to \"([^\"]*)\" page from the main nav panel$")
    public void iNavigateToPageFromTheMainNavPanel(String NavName) throws Throwable {
        wait.waitAndClick(driver, By.linkText(NavName));
        wait.waitUntilGridSpinnersNotPresent();
    }

    @Given("^User navigates to \"([^\"]*)\" site$")
    public void userNavigatesToSite(String arg0) throws Throwable {
        driver.navigate().to(String.format("https://%s", arg0));
    }

    @And("^The login page functionality should be available$")
    public void theLoginPageFunctionalitiesShouldBeAvailable() throws Throwable {
        loginPage.check_loginPageFunctionalities();
    }

    @Given("^I login to OMS site$")
    public void iLoginToOMSSite() throws Throwable {
        loginPage.loginToOMSPage();
        loginPage.navigateToDiligenceLoginPage();
//        wait.waitUntilPresent(By.id("gbox_jqGrid"));
//    pageHelpers.checkPageIsReady(driver);
        credentials.getCredentials();
//        homePage.checkForHomePageVisibility();
    }
//
//    @Given("^I login to OMS site$")
//    public void iLoginToOMSSite() throws Throwable {
//        loginPage.loginToOMSPage();
//        wait.waitUntilPresent(By.id("gbox_jqGrid"));
//    }

    @And("^I am in dashboard page$")
    public void iAmInDashboardPage() throws Throwable {
        wait.waitUntilTextIs(By.xpath("/html/body/div[1]/div[2]/div/div[1]/ul[1]/li[1]/h2"), "Dashboard");
    }

    @And("^I see in progress tile is active$")
    public void iSeeInProgressTileIsActive() throws Throwable {
        WebElement element = webElementExtensions.findElementByDataBind("text", "Title");
        if (element.getText().equals("In Progress")) {
            Assert.assertTrue(element.getAttribute("class").contains("active"));
        }
    }

    @And("^I click on dashboard viewing options and choose \"([^\"]*)\"$")
    public void iClickOnDashboardViewingOptionsAndChoose(String arg0) throws Throwable {
        omsDashboardPage.chooseDashBoardView(arg0);
    }

    @And("^I click on show per page to \"([^\"]*)\" number$")
    public void iClickOnShowPerPageToNumber(String arg0) throws Throwable {
        omsDashboardPage.selectShowPerPage(arg0);
    }

    @And("^I see calendar is available$")
    public void iSeeCalendarIsAvailable() throws Throwable {
        omsDashboardPage.calendar.isDisplayed();
    }

    @And("^If a order is available it should show in calendar$")
    public void ifAOrderIsAvailableItShouldShowInCalendar() throws Throwable {
        String text = driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[2]/div[1]/div/div[2]/div[3]/div/div[3]/div[3]/div/table/tbody/tr[2]/td[4]")).getText();
        System.out.println(text);

        WebElement dateWidget = driver.findElement(By.id("calendarContainer"));
        List<WebElement> columns = dateWidget.findElements(By.tagName("td"));

        for (WebElement cell : columns) {
            String alldates = cell.getAttribute("data-date");
            System.out.println("All the data-dates " + alldates);
//            if (alldates.equals("2018-04-10")) {
//                cell.click();
//                Thread.sleep(4000);
//            }

        }
    }

    @And("^I see a search box is available$")
    public void iSeeASearchBoxIsAvailable() throws Throwable {
        omsDashboardPage.searchBox.isDisplayed();
    }

    @And("^I see create order option is available$")
    public void iSeeCreateOrderOptionIsAvailable() throws Throwable {
        omsDashboardPage.createOrderButton.isDisplayed();
    }

    @And("^I see change password and log off option$")
    public void iSeeChangePasswordOption() throws Throwable {
        omsDashboardPage.userOptionsDropDown.click();
        omsDashboardPage.changePassword.isDisplayed();
        omsDashboardPage.logOff.isDisplayed();
    }

    @And("^I see page changes for \"([^\"]*)\"$")
    public void iSeePageChangesForTeamDashboard(String dashboard) throws Throwable {
        String actual = omsDashboardPage.dashboardViewDropDown.getText();
        Assert.assertEquals("Viewing " + dashboard, actual);
    }

    @And("^I choose \"([^\"]*)\" item per page$")
    public void iChooseItemPerPage(String arg0) throws Throwable {
        omsDashboardPage.selectShowPerPage(arg0);
        wait.waitUntilPresent(omsDashboardPage.tableElements);
    }

    @And("^I fill out the subject \"([^\"]*)\" details$")
    public void iFillOutTheSubjectDetails(String orderform) throws Throwable {
        if (orderform.equals("company")) {
            companyName = createOrder.fillCompanySubjectForm();
            System.out.println("Company name is " + companyName);
        } else if (orderform.equals("individual")) {
            createOrder.fillIndividualSubjectForm();
        }
    }

    @And("^I see the name of the subject is added$")
    public void iSeeTheNameOfTheSubjectIsAdded() throws Throwable {
        String actual = wait.waitAndGetText(driver, By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/div[2]/div[2]/div[2]/div[1]/div[2]/div[1]/div/div/div/div/div/div[1]/span[2]"));
        Assert.assertEquals(companyName.toLowerCase(), actual.toLowerCase());
    }

    @And("^I move to next page$")
    public void iMoveToNextPage() throws Throwable {
        subjectCompanyFormPage.continueButton.click();
    }

    @And("^I fill order details for \"([^\"]*)\" type$")
    public void iFillOrderDetailsForType(String arg0) throws Throwable {
        orders = orderPage.fillOrderDetails(arg0, orderName);
//        orderName = orderPage.fillOrderDetails(arg0);
        System.out.println("Order name is " + Arrays.toString(orders));
    }

    @And("^I review order details have order type and order name$")
    public void iReviewOrderDetails() throws Throwable {
        String orderTypeActual = wait.waitAndGetText(driver, By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/div[2]/div[3]/div[2]/div/div/div[1]/div[1]/p"));
        Assert.assertArrayEquals(orders, new String[]{orderTypeActual, orderName});
        String actualSubjectName = wait.waitAndGetText(driver, By.xpath("/html/body/div[1]/div[2]/div/div/div[2]/div[2]/div[3]/div[2]/div/div/div[2]/div[2]/div[1]/div/div/div/div/div[1]/span[2]"));
        Assert.assertEquals(companyName, actualSubjectName);
    }

    @And("^I submit the order$")
    public void submitOrder() throws Throwable {
        rco.submitOrderButton.click();
        wait.waitUntilPresent(omsDashboardPage.tableElements);
    }

    @And("^I click on Orders$")
    public void iClickOnOrders() throws Throwable {
        homePage.navigateToOrdersPage();
    }

    @And("^I should be able to type \"([^\"]*)\" in Name field$")
    public void iShouldBeAbleToTypeInNameField(String arg0) throws Throwable {

        searchorderpage.fillordername(arg0);
    }

    @And("^I should be able to click on Order type field and select a \"([^\"]*)\"$")
    public void iShouldBeAbleToClickOnOrderTypeFieldAndSelectA(String arg0) throws Throwable {
//        searchorderpage.selectordertype(arg0);
//       selectElements.selectJavaScriptItems("SelectedProductTypeIds", arg0);
          searchorderpage.selectordertype(arg0);

    }

    @And("^I should be able to click Order Status field and select \"([^\"]*)\"$")
    public void iShouldBeAbleToClickOrderStatusFieldAndSelect(String arg0) throws Throwable {
        searchorderpage.fillorderstatus(arg0);
    }

    @And("^I should be able to type \"([^\"]*)\" in Order Number field$")
    public void iShouldBeAbleToTypeInOrderNumberField(String arg0) throws Throwable {
        searchorderpage.ordernumber(arg0);
    }

    @And("^I should be able to click on Search button$")
    public void iShouldBeAbleToClickOnSearchButton() throws Throwable {
       searchorderpage.searchbuttonclick();
    }

    @And("^I should be able to click on Reset button$")
    public void iShouldBeAbleToClickOnResetButton() throws Throwable {
        searchorderpage.resetbuttonclick();
    }

    @Then("^I should be able to see the results$")
    public void iShouldBeAbleToSeeTheResults() throws Throwable {
        searchorderpage.viewresults();
    }

    @And("^I should be able to pick Submited between start and end dates as \"([^\"]*)\" and \"([^\"]*)\" fields$")
    public void iShouldBeAbleToPickSubmitedBetweenStartAndEndDatesAsAndFields(String arg0, String arg1) throws Throwable {
        searchorderpage.submitcal_1();
        searchorderpage.submitcal_2();
    }

    @And("^I should be able to pick Completed between start and end dates as \"([^\"]*)\" and \"([^\"]*)\" fields$")
    public void iShouldBeAbleToPickCompletedBetweenStartAndEndDatesAsAndFields(String arg0, String arg1) throws Throwable {
        searchorderpage.submitcal_3();
        searchorderpage.submitcal_4();

    }



    @And("^I see the order is listed in the table$")
    public void iSeeTheOrderIsListedInTheTable() throws Throwable{

        List<WebElement> clientAccountName = wait.waitAndReturnListElements(driver, By.cssSelector("td[aria-describedby='jqGrid_Name']"));
        for (WebElement element : clientAccountName) {
//            System.out.println(element.getText());
//            Assert.assertEquals("Dark Colossus order", element.getText());
//        }

            if(orderName.equalsIgnoreCase(element.getText())){
                System.out.println("Pass");
            }
//            boolean anyMatch = clientAccountName.stream()
//                    .map(WebElement::getText)
//                    .filter(Objects::nonNull)
//                    .map(String::trim)
//                    .anyMatch(orderName::equals);
//            assertTrue(anyMatch);

//        List<WebElement> elements = wait.waitAndReturnListElements(driver, By.cssSelector("td[aria-describedby='jqGrid_Name']"));
//        for (WebElement element : elements) {
//            System.out.println(element.getText());
//            String alltheText = element.getText();
//            Assert.assertThat(alltheText, CoreMatchers.containsString("Dark Colossus order"));
//            alltheText.contains("FIllll ANd Fill");
//            assertEquals("Dark Colossus order", element.getText());
        }

    }

    @And("^I see name field is available$")
    public void iSeeNameFieldIsAvailable() throws Throwable {
       Assert.assertTrue(orderSearchPage.orderName.isDisplayed());
    }

    @And("^I see order type dropdown is available$")
    public void iSeeOrderTypeDropdownIsAvailable() throws Throwable {
        Assert.assertTrue(orderSearchPage.ordertypebutton.isDisplayed());
    }


    @And("^I see Submitted 'Between Start date and End date' dropdowns are available$")
    public void iSeeSubmittedBetweenStartDateAndEndDateDropdownsAreAvailable() throws Throwable {
        Assert.assertTrue(orderSearchPage.submitstart.isDisplayed());
        Assert.assertTrue(orderSearchPage.calbtn1.isDisplayed());
        Assert.assertTrue(orderSearchPage.submitend.isDisplayed());
        Assert.assertTrue(orderSearchPage.calbtn2.isDisplayed());
    }

    @And("^I see Completed 'Between Start date and End date' dropdowns are available$")
    public void iSeeCompletedBetweenStartDateAndEndDateDropdownsAreAvailable() throws Throwable {
        Assert.assertTrue(orderSearchPage.completestart.isDisplayed());
        Assert.assertTrue(orderSearchPage.calbtn3.isDisplayed());
        Assert.assertTrue(orderSearchPage.completeend.isDisplayed());
        Assert.assertTrue(orderSearchPage.calbtn4.isDisplayed());
    }

    @And("^I see Order Status dropdown is available$")
    public void iSeeOrderStatusDropdownIsAvailable() throws Throwable {
        Assert.assertTrue(orderSearchPage.orderstatusbutton.isDisplayed());
    }

    @And("^I see Order Number field is available$")
    public void iSeeOrderNumberFieldIsAvailable() throws Throwable {
        Assert.assertTrue(orderSearchPage.ordernumber.isDisplayed());
    }

    @And("^I see show more filters link is available$")
    public void iSeeShowMoreFiltersLinkIsAvailable() throws Throwable {
        Assert.assertTrue(orderSearchPage.moreFiltersButton.isDisplayed());
    }

    @And("^I see search and reset buttons are available$")
    public void iSeeSearchAndResetButtonsAreAvailable() throws Throwable {
        Assert.assertTrue(orderSearchPage.resetbutton.isDisplayed());
        Assert.assertTrue(orderSearchPage.searchbutton.isDisplayed());
    }

    @And("^I see Order Name, Order Type, Submitted Start and End date fields are aligned horizontally$")
    public void iSeeOrderNameOrderTypeSubmittedStartAndEndDateFieldsAreAlignedHorizontally() throws Throwable {
      int position = orderSearchPage.orderName.getLocation().y;
        Assert.assertTrue(position == orderSearchPage.ordertypebutton.getLocation().y
                && position == orderSearchPage.submitstart.getLocation().y
                && position == orderSearchPage.calbtn1.getLocation().y
                && position == orderSearchPage.submitend.getLocation().y
                && position == orderSearchPage.calbtn2.getLocation().y);
    }

    @And("^I see Completed Start and End date, Order Status, Order Number fields are aligned horizontally$")
    public void iSeeCompletedStartAndEndDateOrderStatusOrderNumberFieldsAreAlignedHorizontally() throws Throwable {
        int position = orderSearchPage.completestart.getLocation().y;
        Assert.assertTrue(position == orderSearchPage.completestart.getLocation().y
                && position == orderSearchPage.calbtn3.getLocation().y
                && position == orderSearchPage.completeend.getLocation().y
                && position == orderSearchPage.calbtn4.getLocation().y
                && position == orderSearchPage.orderstatusbutton.getLocation().y
                && position == orderSearchPage.ordernumber.getLocation().y);

    }

    @And("^I click on back arrow in calendar to go to previous month$")
    public void iClickOnBackArrowInCalendarToGoToPreviousMonth() throws Throwable {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        orderSearchPage.previousmonth.click();
        System.out.println(omsDashboardPage.calMonth.getText()+" == "+ new SimpleDateFormat("MMM").format(cal.getTime()) + " 2018");
        Assert.assertTrue(omsDashboardPage.calMonth.getText().contains(new SimpleDateFormat("MMM").format(cal.getTime()) + " 2018"));
    }

    @And("^I click on forward arrow in calendar to go to next month$")
    public void iClickOnForwardArrowInCalendarToGoToNextMonth() throws Throwable {
        Calendar cal = Calendar.getInstance();
        orderSearchPage.nextmonth.click();
        System.out.println(omsDashboardPage.calMonth.getText()+" == "+new SimpleDateFormat("MMM").format(cal.getTime()) + " 2018");
        Assert.assertTrue(omsDashboardPage.calMonth.getText().contains(new SimpleDateFormat("MMM").format(cal.getTime()) + " 2018"));
    }

    @And("^I should be able to click Not Submitted tile and see not submitted orders$")
    public void iShouldBeAbleToClickNotSubmittedTileAndSeeNotSubmittedOrders() throws Throwable {
//        omsDashboardPage.notSubmitted.click();
        wait.waitAndClick(omsDashboardPage.notSubmitted);
    }

    @And("^I should be able to click In Progress tile and see in progress orders$")
    public void iShouldBeAbleToClickInProgressTileAndSeeInProgressOrders() throws Throwable {
        omsDashboardPage.inProgress.click();
    }

    @And("^I should be able to click Unread Messages tile and see my unread messages$")
    public void iShouldBeAbleToClickUnreadMessagesTileAndSeeMyUnreadMessages() throws Throwable {
        omsDashboardPage.unreadMessages.click();
    }

    @And("^I should be able to click on Reports Delivered tile view orders with delivered reports$")
    public void iShouldBeAbleToClickOnReportsDeliveredTileViewOrdersWithDeliveredReports() throws Throwable {
        omsDashboardPage.reportsDelivered.click();
    }

    @And("^I click on Order Status dropdown$")
    public void iClickOnOrderStatusDropdown() throws Throwable {
       orderSearchPage.orderstatusbutton.click();
    }


    @Then("^I should not see \"([^\"]*)\" status$")
    public void iShouldNotSeeStatus(String arg0) throws Throwable {
        orderSearchPage.verifyAbsenceOfStatus(arg0);
    }


    @Then("^I get unexpected error on the page$")
    public void iGetUnexpectedErrorOnThePage() throws Throwable {
        driver.findElement(By.className("error-layout-body-content"));
    }


    @And("^I go to a page which is not accesible$")
    public void iGoToAPageWhichIsNotAccesible() throws Throwable {
        driver.get("https://diligenceqa.exiger.com/Content/Fonts/Montserrat/");
    }

    @And("^I go to a page which doesnt exist$")
    public void iGoToAPageWhichDoesntExist() throws Throwable {
        driver.get("https://diligenceqa.exiger.com/Content/Fonts/MontserratTest/");
    }


    @And("^I click on terms and conditions$")
    public void iClickOnTermsAndConditions() throws Throwable {
        omsDashboardPage.termsandconditions.click();
    }

    @And("^I navigate to the terms and conditions page$")
    public void iNavigateToTheTermsAndConditionsPage() throws Throwable {
        omsDashboardPage.tocverify.click();
    }

    @And("^I click on support link$")
    public void iClickOnSupportLink() throws Throwable {
        omsDashboardPage.support.click();
    }

    @And("^I navigate to support page$")
    public void iNavigateToSupportPage() throws Throwable {
        omsDashboardPage.supportverify.click();
    }

    @And("^I log off from the site$")
    public void iLogOffFromTheSite() throws Throwable {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement dropdown = driver.findElement(By.cssSelector(".dropdown-menu"));
        js.executeScript("arguments[0].setAttribute('style', 'display:block;')",dropdown);

        omsDashboardPage.logOff.click();
    }

    @And("^I type \"([^\"]*)\" in search for subjects text box$")
    public void iTypeInSearchForSubjectsTextBox(String arg0) throws Throwable {
        omsDashboardPage.quicksearch.sendKeys("test");
        Thread.sleep(5000);
    }

    @And("^I should be able to click on the suggestion$")
    public void iShouldBeAbleToClickOnTheSuggestion() throws Throwable {
        List <WebElement> list = driver.findElements(By.cssSelector(".ta-subject-container"));
        list.get(0).click();
    }

    @And("^I click on Download Audit$")
    public void iClickOnDownloadAudit() throws Throwable {
        omsDashboardPage.downloadaudit.click();
    }

    @And("^I click on Download Results$")
    public void iClickOnDownloadResults() throws Throwable {
        omsDashboardPage.downloadresults.click();
    }

}











































