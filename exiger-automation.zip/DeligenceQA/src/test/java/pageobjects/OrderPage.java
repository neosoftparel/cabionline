package pageobjects;

import com.github.javafaker.Faker;
import helpers.SelectElements;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import step_definitions.BaseClass;

public class OrderPage extends BaseClass{
    SelectElements selectElements = new SelectElements();
    Faker faker = new Faker();

    public OrderPage(){
        PageFactory.initElements(driver, this);
    }
    
    @FindBy(id = "SelectedClientAccountId")
    public WebElement account;
    
    @FindBy (id = "SelectedProductTypeId")
    public WebElement orderType;

    @FindBy (id = "OrderName")
    public WebElement orderName;
    
    @FindBy (id = "DueDate")
    public WebElement dueDate;

    @FindBy (id = "ReferenceNumber")
    public WebElement referenceNumber;

    @FindBy (id = "nextStepButton")
    public WebElement continueButton;



    public String [] fillOrderDetails(String orderTypeName, String orderNameString){
        selectElements.selectByIndexNumbert(account, 1);
        selectElements.selectByVisibleText(orderType, orderTypeName);
        orderName.sendKeys(orderNameString);
        continueButton.click();
        return new String[]{orderTypeName, orderNameString};
    }
}
