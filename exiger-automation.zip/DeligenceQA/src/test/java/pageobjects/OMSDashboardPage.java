package pageobjects;

import helpers.SelectElements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import step_definitions.BaseClass;

public class OMSDashboardPage extends BaseClass {
    Actions actions = new Actions(driver);

    private SelectElements selectElements = new SelectElements();

    public OMSDashboardPage() {
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "ExternalUserDashboardViewDropDown")
    public WebElement dashboardViewDropDown;

    @FindBy(id = "metric-tile-1")
    public WebElement notSubmittedTile;

    @FindBy(id = "metric-tile-2")
    public WebElement inProgressTile;

    @FindBy(id = "metric-tile-3")
    public WebElement unreadMessagesTile;

    @FindBy(id = "metric-tile-4")
    public WebElement reportsDeliveredTile;

    @FindBy(id = "calendar")
    public WebElement calendar;

    @FindBy(className = "btn-create-dash")
    public WebElement createOrderButton;

    @FindBy(xpath = "/html/body/div[1]/div[2]/div/div[2]/div[1]/div/div[2]/div[1]/div[2]/div/ul/li[2]/select")
    public WebElement showPerPageSelect;
    
    @FindBy (id = "headerSearchBox")
    public WebElement searchBox;
    
    @FindBy (id = "userOptionsDropDown")
    public WebElement userOptionsDropDown;
    
    @FindBy (linkText = "Change Password")
    public WebElement changePassword;

    @FindBy (linkText = "Log Off")
    public WebElement logOff;
    
    @FindBy (id = "gbox_jqGrid")
    public WebElement tableElements;

    @FindBy (className = "fc-left")
    public WebElement calMonth;

    @FindBy (id = "metric-tile-1")
    public WebElement notSubmitted;

    @FindBy (xpath = "//*[@id=\"metric-tile-2\"]/div[3]")
    public WebElement inProgress;

    @FindBy (xpath = "//*[@id=\"metric-tile-4\"]/div[3]")
    public WebElement unreadMessages;

    @FindBy (xpath = "//*[@id=\"metric-tile-3\"]/div[3]")
    public WebElement reportsDelivered;

    @FindBy(linkText = "Terms and Conditions")
    public WebElement termsandconditions;

    @FindBy(linkText = "Terms and Conditions")
    public WebElement tocverify;

    @FindBy(linkText = "Support")
    public WebElement support;

    @FindBy(xpath = "//h2[.='Contact Us']")
    public WebElement supportverify;

    @FindBy(id = "headerSearchBox")
    public WebElement quicksearch;

    @FindBy(id = "DownloadAudit")
    public WebElement downloadaudit;


    @FindBy(id = "DownloadResults")
    public WebElement downloadresults;

    @FindBy(linkText = "Forgot Password")
    public WebElement forgotpassword;

    @FindBy(linkText = "English (US)")
    public WebElement language;



    public void selectShowPerPage(String numberPerPage){
        selectElements.selectByVisibleText(showPerPageSelect, numberPerPage);
    }
    public void chooseDashBoardView(String textToChoose){
        dashboardViewDropDown.click();
        actions.moveToElement(driver.findElement(By.linkText(textToChoose))).click().build().perform();
    }
}
